#pragma once

struct worker
{
    int epoll_fd;
};
