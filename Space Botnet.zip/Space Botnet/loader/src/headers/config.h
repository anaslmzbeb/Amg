#pragma once

#define HTTP_SERVER "185.132.53.207"
#define HTTP_PORT 80

#define TFTP_SERVER "185.132.53.207"
